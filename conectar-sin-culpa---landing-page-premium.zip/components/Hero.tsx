
import React from 'react';
import { ChevronDown } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative flex flex-col items-center justify-center pt-32 pb-20 px-6 bg-pink-pale overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-[-10%] right-[-5%] w-[40rem] h-[40rem] bg-white opacity-20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-[-5%] left-[-5%] w-[30rem] h-[30rem] bg-coral-red opacity-5 rounded-full blur-3xl"></div>

      <div className="max-w-5xl mx-auto text-center relative z-10">
        <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl text-brown-warm leading-[1.1] mb-8">
          Prometiste que no repetirías la historia… <br />
          <span className="italic font-normal">pero a veces reaccionas igual.</span>
        </h1>
        
        <div className="flex flex-col md:flex-row items-center justify-center gap-12 mt-12">
          {/* Mockup Real Image */}
          <div className="w-full md:w-1/2 max-w-sm">
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-coral-red to-orange-400 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-1000 group-hover:duration-200"></div>
              <img 
                src="https://i.imgur.com/X52wxH1.jpeg" 
                alt="Mockup Conectar sin Culpa" 
                className="relative rounded-xl shadow-2xl w-full transform group-hover:-translate-y-2 transition-transform duration-500"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-xl flex flex-col items-center">
                <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Oferta</span>
                <span className="text-2xl font-serif font-bold text-coral-red">$10</span>
              </div>
            </div>
          </div>

          <div className="w-full md:w-1/2 text-left space-y-6">
            <p className="font-serif text-2xl md:text-3xl text-brown-warm/80 leading-relaxed italic">
              "El sistema de 40 segundos para padres que quieren dejar de gritar."
            </p>
            <p className="text-lg text-gray-700 max-w-md">
              Aprende a desactivar tu respuesta de estrés en segundos y reconecta con el amor que sientes por tus hijos, incluso en medio del caos.
            </p>
            <div className="pt-4">
              <a 
                href="#pricing"
                className="inline-block w-full text-center md:w-auto bg-coral-red text-white text-xl px-10 py-5 rounded-2xl font-bold shadow-2xl hover:scale-105 transition-transform hover:bg-red-600 focus:ring-4 focus:ring-red-200"
              >
                EMPEZAR MI TRANSFORMACIÓN POR $10
              </a>
              <p className="text-sm text-gray-500 mt-4 flex items-center justify-center md:justify-start gap-2">
                <span className="flex text-yellow-500">★★★★★</span>
                +5,000 padres transformados
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-12 animate-bounce opacity-40">
        <ChevronDown size={32} className="text-brown-warm" />
      </div>
    </section>
  );
};

export default Hero;
