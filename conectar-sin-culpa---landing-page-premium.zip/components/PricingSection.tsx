
import React from 'react';
import { ShieldCheck, Zap, Clock } from 'lucide-react';

const PricingSection: React.FC = () => {
  return (
    <section id="pricing" className="bg-pink-pale py-16 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border-2 border-coral-red/10">
          <div className="bg-coral-red py-6 text-center text-white px-4">
            <h3 className="flex items-center justify-center gap-2 font-bold uppercase tracking-widest text-sm">
              <Zap size={16} fill="white" /> Oferta de Lanzamiento Exclusiva
            </h3>
          </div>

          <div className="p-10 md:p-12 text-center space-y-10">
            <div className="space-y-4">
              <p className="text-xl font-bold text-brown-warm text-left md:text-center">Resumen de tu transformación:</p>
              <ul className="text-gray-500 space-y-2 text-sm md:text-base text-left">
                <li className="flex justify-between border-b pb-2"><span>Guía Conectar sin Culpa</span> <span className="line-through">$47</span></li>
                <li className="flex justify-between border-b pb-2"><span>Bono 1: Kit Imprimible 30 Días</span> <span className="line-through">$17</span></li>
                <li className="flex justify-between border-b pb-2"><span>Bono 2: Ejercicios por Edad</span> <span className="line-through">$27</span></li>
                <li className="flex justify-between border-b pb-2"><span>Bono 3: 30 Actividades Casa</span> <span className="line-through">$19</span></li>
                <li className="flex justify-between border-b pb-2"><span>Bono 4: Agente IA Guía Parental</span> <span className="line-through">$37</span></li>
                <li className="flex justify-between border-b pb-2"><span>Bono 5: Comunidad VIP</span> <span className="line-through">$36</span></li>
                <li className="flex justify-between font-bold text-brown-warm pt-4 text-2xl">
                  <span>VALOR TOTAL:</span> 
                  <span className="text-red-500 line-through">$183</span>
                </li>
              </ul>
            </div>

            <div className="py-4">
              <p className="text-gray-600 mb-2 uppercase tracking-widest font-bold">Hoy obtienes todo por solo:</p>
              <div className="flex items-center justify-center gap-4">
                <span className="text-gray-300 text-4xl md:text-6xl font-serif line-through">$183</span>
                <span className="text-coral-red text-7xl md:text-9xl font-serif font-black animate-pulse">$10</span>
              </div>
            </div>

            <div className="space-y-6">
              <button className="w-full bg-coral-red text-white text-2xl md:text-3xl font-bold py-6 px-8 rounded-2xl shadow-2xl hover:bg-red-600 transform hover:scale-[1.02] transition-all active:scale-95">
                ¡SÍ, QUIERO MI TRANSFORMACIÓN POR $10!
              </button>
              
              <div className="flex flex-col md:flex-row items-center justify-center gap-8 pt-4">
                <div className="flex items-center gap-3 text-left">
                  <div className="w-16 h-16 rounded-full border-4 border-yellow-500/30 flex items-center justify-center bg-yellow-50">
                    <ShieldCheck size={32} className="text-yellow-600" />
                  </div>
                  <div>
                    <h4 className="font-bold text-brown-warm">Garantía de 7 días</h4>
                    <p className="text-sm text-gray-500">Sin preguntas, 100% devolución.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 text-left">
                  <div className="w-16 h-16 rounded-full border-4 border-coral-red/30 flex items-center justify-center bg-red-50">
                    <Clock size={32} className="text-coral-red" />
                  </div>
                  <div>
                    <h4 className="font-bold text-brown-warm italic">Tiempo Limitado</h4>
                    <p className="text-sm text-gray-500">El precio sube en 24 horas.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Imagen final de cierre solicitada */}
            <div className="pt-4">
              <img 
                src="https://i.imgur.com/QReEuGN.png" 
                alt="Familia conectada y feliz" 
                className="w-full h-auto rounded-2xl shadow-lg border border-gray-100"
              />
            </div>
          </div>
        </div>

        <div className="mt-8 text-center text-gray-500 text-sm">
          <p>Pagos seguros protegidos por encriptación SSL de 256 bits.</p>
          <div className="flex justify-center gap-4 mt-4 opacity-50 grayscale">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="visa" className="h-6" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="mastercard" className="h-6" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="paypal" className="h-6" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
