
import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, X, Bot, User } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

const ChatAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{role: 'user' | 'bot', text: string}[]>([
    { role: 'bot', text: 'Hola, soy tu guía de acompañamiento. Entiendo que la crianza puede ser agotadora. ¿Qué es lo que más te está costando hoy con tus hijos?' }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userMsg,
        config: {
          systemInstruction: `Eres un experto en crianza consciente y psicología infantil de la guía "Conectar sin Culpa". 
          Tu objetivo es ser extremadamente empático, validando los sentimientos de cansancio y culpa de los padres.
          Ofrece consejos breves basados en la autorregulación y suavemente menciona cómo nuestra guía de $10 puede ayudarles a profundizar.
          Mantén un tono cálido, profesional y alentador. Nunca juzgues.`,
          temperature: 0.7,
        }
      });

      const botText = response.text || "Lo siento, tuve un pequeño problema. Pero estoy aquí para escucharte.";
      setMessages(prev => [...prev, { role: 'bot', text: botText }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, { role: 'bot', text: "Entiendo tu dolor. Estoy aquí para apoyarte. La guía 'Conectar sin Culpa' tiene herramientas justo para lo que me cuentas." }]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {isOpen ? (
        <div className="bg-white w-[350px] md:w-[400px] h-[500px] rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-gray-100">
          <div className="bg-brown-warm p-4 flex justify-between items-center text-white">
            <div className="flex items-center gap-2">
              <div className="bg-coral-red p-2 rounded-full">
                <Bot size={20} />
              </div>
              <div>
                <p className="font-bold text-sm">Asistente Empático</p>
                <p className="text-[10px] opacity-70">En línea ahora</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-1 rounded-full">
              <X size={20} />
            </button>
          </div>

          <div ref={scrollRef} className="flex-grow p-4 overflow-y-auto space-y-4 bg-pink-pale/30">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${
                  m.role === 'user' 
                    ? 'bg-brown-warm text-white rounded-tr-none' 
                    : 'bg-white text-gray-700 shadow-sm rounded-tl-none border border-gray-100'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-white p-3 rounded-2xl shadow-sm animate-pulse flex gap-1">
                  <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                  <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t bg-white">
            <div className="flex gap-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Cuéntame, ¿cómo te sientes?"
                className="flex-grow bg-gray-50 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-coral-red/20 outline-none"
              />
              <button 
                onClick={handleSend}
                disabled={isTyping}
                className="bg-coral-red text-white p-2 rounded-xl hover:bg-red-600 transition-colors disabled:opacity-50"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-brown-warm text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform relative group"
        >
          <MessageCircle size={28} />
          <span className="absolute -top-2 -right-2 bg-coral-red text-white text-[10px] font-bold px-2 py-1 rounded-full">1</span>
          <div className="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-white text-brown-warm px-4 py-2 rounded-xl text-sm font-bold shadow-xl whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
            ¿Necesitas hablar?
          </div>
        </button>
      )}
    </div>
  );
};

export default ChatAssistant;
