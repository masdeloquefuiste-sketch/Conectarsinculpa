
import React from 'react';
import { CheckCircle2, Heart } from 'lucide-react';

const EmpathySection: React.FC = () => {
  return (
    <section className="bg-brown-warm py-16 px-6 relative overflow-hidden">
      {/* Decorative floral element (SVG pattern) */}
      <div className="absolute top-0 right-0 p-12 opacity-10 pointer-events-none">
        <Heart size={300} className="text-white" />
      </div>

      <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center gap-16">
        <div className="w-full lg:w-1/2 order-2 lg:order-1">
          <div className="space-y-8">
            <h2 className="font-serif text-4xl md:text-5xl text-white leading-tight">
              Sabemos que amas a tus hijos, <br />
              <span className="italic">pero el cansancio te gana...</span>
            </h2>
            
            <p className="text-xl text-white/80 leading-relaxed">
              No eres una mala madre o un mal padre. Eres un ser humano con el sistema nervioso sobrecargado. El ciclo de "Grito - Arrepentimiento - Promesa" se rompe con herramientas, no solo con voluntad.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                "Rompe el ciclo de reactividad",
                "Gestiona berrinches sin explotar",
                "Reclama tu paz mental diaria",
                "Crea un refugio seguro en casa",
                "Elimina la culpa al final del día",
                "Conexión real sobre obediencia"
              ].map((item, idx) => (
                <div key={idx} className="flex items-start gap-3 text-white">
                  <CheckCircle2 className="text-coral-red flex-shrink-0 mt-1" size={20} />
                  <span className="text-lg font-light">{item}</span>
                </div>
              ))}
            </div>

            <div className="pt-8">
              <blockquote className="border-l-4 border-coral-red pl-6 italic text-white/70 text-lg font-serif">
                "Pensé que ya era tarde para sanar el vínculo, pero esta guía me dio el 'reset' que mi familia necesitaba desesperadamente."
                <footer className="mt-2 text-white font-sans text-sm not-italic">— María G., Madre de 2</footer>
              </blockquote>
            </div>
          </div>
        </div>

        <div className="w-full lg:w-1/2 order-1 lg:order-2">
          <div className="relative rounded-3xl overflow-hidden shadow-2xl group">
            <img 
              src="https://i.imgur.com/Vl4D1rZ.png" 
              alt="Sensibilización emocional" 
              className="w-full h-[600px] object-cover filter brightness-90 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-brown-warm via-transparent opacity-60"></div>
            <div className="absolute bottom-8 left-8 right-8 text-white">
              <p className="font-serif text-2xl italic">Rompe el ciclo hoy.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EmpathySection;
