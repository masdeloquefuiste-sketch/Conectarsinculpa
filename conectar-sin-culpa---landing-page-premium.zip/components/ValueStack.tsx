
import React from 'react';
import { 
  BookOpenCheck, 
  Printer, 
  Baby, 
  Puzzle, 
  Sparkles, 
  Users,
  Star
} from 'lucide-react';

const ValueStack: React.FC = () => {
  const items = [
    {
      title: "Guía Principal: Conectar sin Culpa",
      desc: "El método paso a paso para la autorregulación emocional adulta y crianza consciente.",
      price: "$47",
      icon: <BookOpenCheck className="text-coral-red" size={48} />,
      isBonus: false,
    },
    {
      title: "BONO #1: Kit Imprimible – 30 Días de Conexión",
      desc: "Calendario, retos diarios, frases de regulación y actividades de presencia consciente listos para imprimir.",
      price: "$17",
      icon: <Printer className="text-coral-red" size={48} />,
      isBonus: true,
    },
    {
      title: "BONO #2: Ejercicios por Edad + Plantilla",
      desc: "Dinámicas específicas desde niños pequeños hasta preadolescentes y plantilla de reunión familiar.",
      price: "$27",
      icon: <Baby className="text-coral-red" size={48} />,
      isBonus: true,
    },
    {
      title: "BONO #3: 30 Actividades Prácticas en Casa",
      desc: "Juegos emocionales y dinámicas para fortalecer el vínculo sin gastar dinero con materiales caseros.",
      price: "$19",
      icon: <Puzzle className="text-coral-red" size={48} />,
      isBonus: true,
    },
    {
      title: "BONO #4: Acceso al Agente IA “Mi Guía Parental”",
      desc: "Asistente digital 24/7 que te sugiere cómo actuar y regularte en momentos difíciles en tiempo real.",
      price: "$37",
      icon: <Sparkles className="text-coral-red" size={48} />,
      isBonus: true,
    },
    {
      title: "BONO #5: Comunidad VIP de Apoyo",
      desc: "Acceso exclusivo a nuestro grupo privado para compartir victorias y dudas con otros padres en un entorno seguro.",
      price: "$36",
      icon: <Users className="text-coral-red" size={48} />,
      isBonus: true,
    }
  ];

  return (
    <section className="py-16 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-serif text-4xl md:text-5xl text-brown-warm mb-4">Lo que vas a recibir para reconstruir tu hogar</h2>
          <p className="text-gray-500 max-w-2xl mx-auto italic text-lg font-serif">Todo lo que necesitas para pasar del caos a la calma, paso a paso.</p>
          <div className="w-24 h-1 bg-coral-red mx-auto rounded-full mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {items.map((item, idx) => (
            <div key={idx} className="group bg-white border border-gray-100 rounded-3xl p-10 shadow-xl hover:shadow-2xl transition-all duration-300 flex flex-col relative overflow-hidden">
              {/* Decorative background element */}
              <div className="absolute -top-10 -right-10 w-32 h-32 bg-pink-pale rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"></div>
              
              {item.isBonus && (
                <div className="absolute top-6 right-6 flex items-center gap-1 bg-coral-red text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase z-20 shadow-md">
                  <Star size={10} fill="white" /> Regalo
                </div>
              )}
              
              {/* Icon Section - Now more prominent */}
              <div className="mb-8 flex justify-center">
                <div className="w-24 h-24 bg-pink-pale rounded-full flex items-center justify-center relative group-hover:scale-110 transition-transform duration-500 shadow-inner">
                  <div className="absolute inset-0 bg-coral-red opacity-0 group-hover:opacity-5 rounded-full transition-opacity"></div>
                  {item.icon}
                </div>
              </div>

              <div className="text-center space-y-4 flex-grow">
                {item.isBonus && (
                  <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-coral-red block">Bono Exclusivo</span>
                )}
                <h3 className="font-serif text-2xl text-brown-warm font-bold leading-tight min-h-[3rem]">
                  {item.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed text-base">
                  {item.desc}
                </p>
              </div>
              
              <div className="flex flex-col items-center border-t border-dashed border-gray-200 mt-8 pt-6">
                <span className="text-gray-400 line-through text-sm font-medium mb-1">Valor real: {item.price}</span>
                <span className="text-coral-red font-bold text-lg uppercase tracking-wider italic">
                  {item.isBonus ? '¡GRATIS HOY!' : 'INCLUIDO'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ValueStack;
