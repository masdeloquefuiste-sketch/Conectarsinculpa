
import React from 'react';
import { Mail, ShieldCheck } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white pt-16 pb-12 px-6 border-t border-gray-100">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="space-y-6">
            <div className="font-serif text-3xl font-bold text-brown-warm">
              Conectar <span className="italic text-coral-red">sin Culpa</span>
            </div>
            <p className="text-gray-500 text-lg leading-relaxed">
              Dedicados a transformar hogares a través de la autorregulación y la empatía profunda. Porque tus hijos merecen tu mejor versión.
            </p>
          </div>

          <div className="space-y-6">
            <h4 className="font-bold text-brown-warm uppercase tracking-widest text-sm">Soporte y Contacto</h4>
            <ul className="space-y-4 text-gray-600">
              <li className="flex items-center gap-2 hover:text-coral-red transition-colors cursor-pointer">
                <Mail size={18} /> soporte@conectarsinculpa.com
              </li>
              <li className="flex items-center gap-2 hover:text-coral-red transition-colors cursor-pointer">
                <ShieldCheck size={18} /> Política de Privacidad
              </li>
              <li className="flex items-center gap-2 hover:text-coral-red transition-colors cursor-pointer">
                Términos de Servicio
              </li>
            </ul>
          </div>

          <div className="bg-pink-pale p-8 rounded-3xl space-y-4">
            <h4 className="font-bold text-brown-warm uppercase tracking-widest text-sm text-center">¡Última Oportunidad!</h4>
            <p className="text-center text-brown-warm/80 italic font-serif text-lg">
              "Precio de lanzamiento por tiempo limitado. No dejes que otro día pase con gritos."
            </p>
            <a 
              href="#pricing"
              className="block w-full text-center bg-coral-red text-white font-bold py-3 rounded-xl hover:bg-red-600 transition-colors"
            >
              ACCESO INSTANTÁNEO $10
            </a>
          </div>
        </div>

        <div className="border-t pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-gray-400 text-sm">
          <p>© 2025 Conectar sin Culpa. Todos los derechos reservados.</p>
          <p className="italic">Desarrollado con amor por expertos en crianza.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
