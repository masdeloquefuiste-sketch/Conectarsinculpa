
import React from 'react';
import { Heart, Sparkles } from 'lucide-react';

const ImagineSection: React.FC = () => {
  return (
    <section className="py-16 px-6 bg-white relative">
      {/* Sutil decoration */}
      <div className="absolute top-0 right-0 w-64 h-64 opacity-10 pointer-events-none">
        <img src="https://www.transparentpng.com/download/flower/lavender-transparent-background-5.png" alt="lavender" className="w-full h-full object-contain" />
      </div>
      <div className="absolute bottom-0 left-0 w-64 h-64 opacity-10 pointer-events-none scale-x-[-1]">
        <img src="https://www.transparentpng.com/download/flower/lavender-transparent-background-5.png" alt="lavender" className="w-full h-full object-contain" />
      </div>

      <div className="max-w-4xl mx-auto text-center space-y-8">
        <div className="inline-flex items-center gap-2 bg-pink-pale px-4 py-2 rounded-full text-brown-warm font-semibold text-sm">
          <Sparkles size={16} className="text-coral-red" />
          PSICOLOGÍA POSITIVA APLICADA
        </div>

        <h2 className="font-serif text-4xl md:text-5xl text-brown-warm leading-tight">
          Imagina no irte a dormir <span className="italic">con culpa...</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mt-10">
          {[
            "Poder abrazar a tus hijos con paz real al final del día.",
            "Sentir que controlas tus impulsos, no que ellos te controlan a ti.",
            "Ver cómo tus hijos confían más en ti porque saben que eres su calma.",
            "Dejar de sentirte una 'mala persona' por perder la paciencia.",
            "Disfrutar de la risa genuina en lugar de la tensión constante.",
            "Recuperar tu energía vital para lo que realmente importa."
          ].map((text, idx) => (
            <div key={idx} className="flex gap-4 items-start group">
              <div className="w-10 h-10 rounded-full bg-pink-pale flex items-center justify-center flex-shrink-0 group-hover:bg-coral-red transition-colors duration-300">
                <Heart size={18} className="text-coral-red group-hover:text-white" />
              </div>
              <p className="text-lg text-gray-700 leading-snug">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImagineSection;
